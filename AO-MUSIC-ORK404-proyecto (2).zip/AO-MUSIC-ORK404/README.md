# AO MUSIC ORK404

Aplicación Android nativa de reproducción musical local y búsqueda de pistas en Jamendo. Desarrollador mostrado: **AO ORK404**. Sin publicidad integrada.

## Lo implementado

- Biblioteca de audio del teléfono mediante MediaStore y permiso explícito del sistema.
- Reproducción con ExoPlayer/Media3 y servicio MediaSession para notificación/controles multimedia y reproducción en segundo plano.
- Controles anterior, reproducir/pausar, siguiente, progreso, aleatorio y repetir una pista.
- Búsqueda local por título, artista o álbum; consulta remota al catálogo Jamendo.
- Favoritos persistentes, creación de playlists y opción de añadir pistas a una playlist.
- Descarga con Android DownloadManager **solo** cuando la respuesta de Jamendo marca `audiodownload_allowed=true` y entrega una URL de descarga. En el menú se abre también la licencia devuelta por la API cuando existe.
- Tema oscuro y opción de tema claro, portada remota para resultados y ajustes.
- Icono de aplicación AO.

La app no incluye música comercial, extracción de servicios de pago, enlaces de descarga inventados ni anuncios. Jamendo requiere un `client_id` propio. Sin esa clave, la biblioteca y reproducción locales siguen disponibles.

## Compilar APK con Android Studio

1. Instala Android Studio actual con Android SDK Platform 35 y JDK 17.
2. Abre la carpeta `AO-MUSIC-ORK404` como proyecto. Acepta la sincronización de Gradle y deja que descargue dependencias desde Google Maven Central.
3. Para APK de pruebas, usa **Build → Build APK(s)**. El archivo suele quedar en `app/build/outputs/apk/debug/app-debug.apk`.
4. Transfiere el APK al Motorola, ábrelo y autoriza instalar aplicaciones desde esa fuente si Android lo solicita. Al abrir la app, acepta el permiso de audio para que aparezca la música local.

Desde una terminal con Gradle, JDK 17 y Android SDK 35 configurados, ejecuta desde la carpeta del proyecto:

```sh
gradle assembleDebug
```

Para una entrega de producción, crea un keystore propio y genera un APK/AAB firmado en **Build → Generate Signed Bundle / APK**. No compartas el keystore ni su contraseña.

## Activar el catálogo Jamendo

1. Solicita/crea una aplicación y su `client_id` en el portal oficial de desarrolladores de Jamendo: https://developer.jamendo.com/
2. En la app, toca el engrane, pega el identificador y guarda.
3. Entra en **Jamendo**, escribe una búsqueda y toca **Buscar en Jamendo**.
4. El botón de descarga aparece como autorizado solo si la API lo permite para esa pista. Comprueba la licencia antes de reutilizar o redistribuir música: los derechos y atribuciones dependen de cada pista. La app reproduce el campo `audio` y respeta `audiodownload_allowed`/`audiodownload` de la API.

Referencia API utilizada: https://developer.jamendo.com/v3.0/tracks

## GitHub

El proyecto incluye un workflow de GitHub Actions en `.github/workflows/android.yml` para compilar el APK en cada push. Para publicarlo, crea un repositorio vacío bajo tu cuenta y sube esta carpeta como repositorio Git. No se creó un repositorio remoto en tu cuenta ni se subió código desde este entorno.

## Límites transparentes

- No incluye cuentas ni streaming de Spotify, YouTube Music u otros catálogos comerciales; sus licencias no permiten ofrecer su audio como un reproductor externo genérico.
- El catálogo Jamendo necesita un `client_id` que debes obtener tú. No hay clave oculta ni se envía a un servidor de AO.
- Las playlists/favoritos se almacenan localmente en preferencias de esta instalación.
- Se preparó el código fuente, pero este entorno no trae JDK, Gradle ni Android SDK: no fue posible compilar, instalar ni validar la reproducción en un Motorola aquí. Debe compilarse y probarse con Android Studio/SDK antes de distribuirla.

## Tecnologías

Kotlin, Android SDK 35, Media3 ExoPlayer/MediaSession, MediaStore, DownloadManager, OkHttp, Glide.
