package com.aoork404.music

import android.Manifest
import android.app.DownloadManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.bumptech.glide.Glide
import java.io.File
import java.util.concurrent.ExecutionException

class MainActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("ao_music", MODE_PRIVATE) }
    private var controller: MediaController? = null
    private var allTracks = mutableListOf<Track>()
    private var remoteTracks = mutableListOf<Track>()
    private var visibleTracks = mutableListOf<Track>()
    private var page = "Mi música"
    private var query = ""
    private var search: EditText? = null
    private var listBox: LinearLayout? = null
    private var status: TextView? = null
    private var miniTitle: TextView? = null
    private var miniArtist: TextView? = null
    private var playButton: TextView? = null
    private var progress: SeekBar? = null
    private var progressLabel: TextView? = null
    private var root: LinearLayout? = null
    private val handler = Handler(Looper.getMainLooper())
    private val favorites: MutableSet<String> get() = prefs.getStringSet("favorites", emptySet())?.toMutableSet() ?: mutableSetOf()
    private val askPermissions = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (hasAudioPermission()) loadDeviceTracks() else showStatus("Da permiso de audio para leer tu biblioteca local.")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        connectPlayer()
        if (hasAudioPermission()) loadDeviceTracks() else requestAudioPermission()
        handler.post(progressUpdater)
    }

    private fun hasAudioPermission(): Boolean = if (Build.VERSION.SDK_INT >= 33)
        ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_AUDIO) == PackageManager.PERMISSION_GRANTED
    else ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun requestAudioPermission() {
        val permissions = mutableListOf(if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE)
        if (Build.VERSION.SDK_INT >= 33) permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        askPermissions.launch(permissions.toTypedArray())
    }

    private fun connectPlayer() {
        val token = SessionToken(this, ComponentName(this, MusicService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        future.addListener({
            try {
                controller = future.get().also { player ->
                    player.addListener(object : androidx.media3.common.Player.Listener {
                        override fun onMediaItemTransition(mediaItem: androidx.media3.common.MediaItem?, reason: Int) = updateNowPlaying()
                        override fun onIsPlayingChanged(isPlaying: Boolean) = updateNowPlaying()
                        override fun onPlaybackStateChanged(playbackState: Int) = updateNowPlaying()
                    })
                    updateNowPlaying()
                }
            } catch (_: ExecutionException) { showStatus("No se pudo iniciar el reproductor.") }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun buildUi() {
        val bg = if (prefs.getBoolean("light", false)) Color.rgb(244, 244, 249) else Color.rgb(11, 11, 18)
        val fg = if (prefs.getBoolean("light", false)) Color.rgb(28, 28, 42) else Color.rgb(245, 243, 255)
        val muted = if (prefs.getBoolean("light", false)) Color.rgb(95, 96, 115) else Color.rgb(164, 162, 181)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        val outer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        root = outer
        val scroller = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(20), dp(20), dp(14)) }
        scroller.addView(content)
        outer.addView(scroller, LinearLayout.LayoutParams(-1, 0, 1f))

        val brandRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val brand = TextView(this).apply { text = "AO  MUSIC"; setTextColor(fg); textSize = 25f; typeface = Typeface.create("sans-serif", Typeface.BOLD) }
        val settings = TextView(this).apply { text = "⚙"; textSize = 23f; gravity = Gravity.CENTER; setTextColor(fg); background = rounded(0xFF1A1925.toInt(), 18); setPadding(dp(13), dp(7), dp(13), dp(7)); setOnClickListener { openSettings() } }
        brandRow.addView(brand, LinearLayout.LayoutParams(0, -2, 1f)); brandRow.addView(settings)
        content.addView(brandRow)
        content.addView(label("ORK404  ·  TU MÚSICA, A TU RITMO", 12f, 0xFF9A82FF.toInt()).apply { setPadding(0, dp(2), 0, dp(14)) })

        search = EditText(this).apply {
            hint = "Buscar canción, artista o álbum"; setHintTextColor(muted); setTextColor(fg); textSize = 15f
            singleLine = true; setPadding(dp(16), 0, dp(16), 0); background = rounded(if (prefs.getBoolean("light", false)) 0xFFFFFFFF.toInt() else 0xFF1A1925.toInt(), 18)
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { query = s?.toString().orEmpty(); renderTracks() }
                override fun afterTextChanged(s: Editable?) {}
            })
        }
        content.addView(search, LinearLayout.LayoutParams(-1, dp(52)))
        content.addView(horizontalNav(fg, muted), LinearLayout.LayoutParams(-1, dp(50)))
        content.addView(label("PARA TI", 12f, 0xFF9A82FF.toInt()).apply { setPadding(0, dp(13), 0, dp(4)) })
        content.addView(label("Tu música, sin anuncios", 23f, fg).apply { typeface = Typeface.DEFAULT_BOLD })
        content.addView(label("Archivos del teléfono y catálogo abierto con licencias", 13f, muted).apply { setPadding(0, dp(4), 0, dp(14)) })
        status = label("", 13f, muted).apply { setPadding(0, dp(8), 0, dp(8)) }
        content.addView(status)
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(listBox)

        val now = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(10), dp(16), dp(8)); background = rounded(0xFF171622.toInt(), 20) }
        val seekRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        progressLabel = TextView(this).apply { text = "0:00"; setTextColor(muted); textSize = 10f }
        progress = SeekBar(this).apply { max = 1000; progressTintList = android.content.res.ColorStateList.valueOf(0xFF9A82FF.toInt()); thumbTintList = android.content.res.ColorStateList.valueOf(0xFFB9A8FF.toInt()); setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, value: Int, fromUser: Boolean) { if (fromUser) controller?.let { if (it.duration > 0) progressLabel?.text = time(it.duration * value / 1000) } }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) { controller?.let { if (it.duration > 0) it.seekTo(it.duration * (seekBar?.progress ?: 0) / 1000) } }
        }) }
        val duration = TextView(this).apply { text = "0:00"; setTextColor(muted); textSize = 10f }
        seekRow.addView(progressLabel); seekRow.addView(progress, LinearLayout.LayoutParams(0, dp(28), 1f)); seekRow.addView(duration)
        now.addView(seekRow)
        val controls = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        miniTitle = TextView(this).apply { text = "AO MUSIC ORK404"; setTextColor(fg); textSize = 14f; typeface = Typeface.DEFAULT_BOLD; maxLines = 1 }
        miniArtist = TextView(this).apply { text = "Elige una canción"; setTextColor(muted); textSize = 12f; maxLines = 1 }
        info.addView(miniTitle); info.addView(miniArtist)
        val prev = control("⏮", fg) { controller?.seekToPreviousMediaItem() }
        val playControl = control("▶", fg) { togglePlay() }
        playButton = playControl
        val next = control("⏭", fg) { controller?.seekToNextMediaItem() }
        controls.addView(info, LinearLayout.LayoutParams(0, -2, 1f)); controls.addView(prev); controls.addView(playControl); controls.addView(next)
        now.addView(controls)
        now.setOnClickListener { if (controller?.currentMediaItem != null) showFullPlayer() }
        outer.addView(now, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(12), dp(6), dp(12), dp(9)) })
        setContentView(outer)
    }

    private fun horizontalNav(fg: Int, muted: Int): HorizontalScrollView {
        val scroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        listOf("Mi música", "Jamendo", "Favoritos", "Playlists", "Descargas").forEach { title ->
            val b = TextView(this).apply {
                text = title; textSize = 13f; gravity = Gravity.CENTER; setTextColor(if (page == title) fg else muted)
                background = if (page == title) rounded(0xFF2A2340.toInt(), 18) else null
                setPadding(dp(13), dp(8), dp(13), dp(8)); setOnClickListener { page = title; renderTracks(); if (title == "Jamendo") showStatus("Busca una canción y toca Buscar en Jamendo.") }
            }
            row.addView(b, LinearLayout.LayoutParams(-2, dp(42)).apply { rightMargin = dp(5) })
        }
        scroll.addView(row); return scroll
    }

    private fun loadDeviceTracks() {
        if (!hasAudioPermission()) return
        val tracks = mutableListOf<Track>()
        val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL) else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.ALBUM_ID, MediaStore.Audio.Media.IS_MUSIC)
        try {
            contentResolver.query(collection, projection, "${MediaStore.Audio.Media.IS_MUSIC} != 0", null, "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC")?.use { cursor: Cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val albumIdCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol); val albumId = cursor.getLong(albumIdCol)
                    tracks.add(Track("device:$id", cursor.getString(titleCol) ?: "Sin título", cursor.getString(artistCol) ?: "Artista desconocido", cursor.getString(albumCol) ?: "", Uri.withAppendedPath(collection, id.toString()).toString(), "content://media/external/audio/albumart/$albumId", cursor.getLong(durationCol)))
                }
            }
        } catch (_: Exception) { showStatus("No se pudo leer la biblioteca multimedia.") }
        allTracks = tracks
        showStatus(if (tracks.isEmpty()) "Aún no hay canciones locales. Copia audio al teléfono y actualiza." else "${tracks.size} canciones locales disponibles")
        renderTracks()
    }

    private fun renderTracks() {
        val box = listBox ?: return
        box.removeAllViews()
        val source = when (page) {
            "Jamendo" -> remoteTracks
            "Favoritos" -> allTracks.filter { it.id in favorites } + remoteTracks.filter { it.id in favorites }
            "Playlists" -> playlistTracks()
            "Descargas" -> downloadedTracks()
            else -> allTracks
        }
        visibleTracks = source.filter { query.isBlank() || it.title.contains(query, true) || it.artist.contains(query, true) || it.album.contains(query, true) }.toMutableList()
        if (page == "Jamendo" && visibleTracks.isNotEmpty()) {
            val searchOnline = actionButton("Buscar en Jamendo", "#8B5CF6") { searchJamendo() }
            box.addView(searchOnline, LinearLayout.LayoutParams(-1, dp(44)).apply { bottomMargin = dp(8) })
        } else if (page == "Jamendo") {
            box.addView(actionButton("Buscar en Jamendo", "#8B5CF6") { searchJamendo() }, LinearLayout.LayoutParams(-1, dp(44)).apply { bottomMargin = dp(8) })
        }
        if (page == "Playlists") box.addView(actionButton("＋ Crear playlist", "#29253B") { createPlaylist() }, LinearLayout.LayoutParams(-1, dp(44)).apply { bottomMargin = dp(8) })
        if (page == "Descargas") box.addView(actionButton("Actualizar estado de descargas", "#29253B") { renderTracks() }, LinearLayout.LayoutParams(-1, dp(44)).apply { bottomMargin = dp(8) })
        if (visibleTracks.isEmpty()) {
            val empty = when (page) { "Jamendo" -> "Escribe un título, artista o álbum y pulsa Buscar en Jamendo."; "Favoritos" -> "Tus favoritos aparecerán aquí."; "Playlists" -> "Crea una playlist y guarda canciones desde ⋮."; "Descargas" -> "Las descargas autorizadas aparecerán aquí."; else -> "No hay canciones que coincidan con tu búsqueda." }
            box.addView(label(empty, 14f, 0xFFA4A2B5.toInt()).apply { setPadding(dp(5), dp(18), dp(5), dp(18)) })
            return
        }
        visibleTracks.take(120).forEachIndexed { index, track ->
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(9), dp(8), dp(6), dp(8)); background = rounded(0xFF15141E.toInt(), 16); setOnClickListener { if (track.source == Track.Source.DOWNLOAD && !downloadExists(track)) showStatus("La descarga aún no termina; revisa la notificación del sistema.") else playQueue(index) } }
            val cover = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; background = rounded(0xFF32294B.toInt(), 12) }
            if (!track.artwork.isNullOrBlank()) Glide.with(this).load(track.artwork).centerCrop().placeholder(android.R.drawable.ic_media_play).into(cover) else cover.setImageResource(android.R.drawable.ic_media_play)
            row.addView(cover, LinearLayout.LayoutParams(dp(52), dp(52)))
            val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(11), 0, dp(5), 0) }
            texts.addView(TextView(this).apply { text = track.title; setTextColor(0xFFF5F3FF.toInt()); textSize = 14f; typeface = Typeface.DEFAULT_BOLD; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END })
            val subtitle = if (track.source == Track.Source.DOWNLOAD && !downloadExists(track)) "Descarga en curso · ${track.artist}" else "${track.artist}  ·  ${if (track.source == Track.Source.JAMENDO) "Jamendo" else track.album}"
            texts.addView(TextView(this).apply { text = subtitle; setTextColor(0xFFA4A2B5.toInt()); textSize = 12f; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END })
            row.addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(TextView(this).apply { text = "⋮"; textSize = 24f; gravity = Gravity.CENTER; setTextColor(0xFFC4B5FD.toInt()); setPadding(dp(8), 0, dp(8), 0); setOnClickListener { showTrackOptions(track) } })
            box.addView(row, LinearLayout.LayoutParams(-1, dp(70)).apply { bottomMargin = dp(7) })
        }
    }

    private fun playQueue(index: Int) {
        if (visibleTracks.isEmpty()) return
        val safeIndex = index.coerceIn(0, visibleTracks.lastIndex)
        controller?.apply {
            setMediaItems(visibleTracks.map { it.toMediaItem() }, safeIndex, 0L)
            prepare(); play()
        } ?: showStatus("Iniciando el reproductor… vuelve a tocar la canción.")
    }

    private fun searchJamendo() {
        val q = search?.text?.toString()?.trim().orEmpty()
        if (q.isBlank()) { showStatus("Escribe el nombre de una canción o artista primero."); return }
        showStatus("Buscando en Jamendo…")
        JamendoApi.search(prefs.getString("jamendo_client_id", "").orEmpty(), q) { result, error ->
            runOnUiThread {
                if (error != null) showStatus(error) else {
                    remoteTracks = (result ?: emptyList()).toMutableList()
                    showStatus("${remoteTracks.size} resultados de Jamendo. Licencias y descargas dependen de cada pista.")
                    page = "Jamendo"; renderTracks()
                }
            }
        }
    }

    private fun showTrackOptions(track: Track) {
        val actions = mutableListOf<Pair<String, () -> Unit>>()
        actions.add("${if (track.id in favorites) "Quitar de" else "Añadir a"} favoritos" to {
            val f = favorites
            if (!f.add(track.id)) f.remove(track.id)
            prefs.edit().putStringSet("favorites", f).apply(); renderTracks()
            showStatus(if (track.id in f) "Añadida a favoritos." else "Quitada de favoritos.")
        })
        actions.add("Añadir a playlist" to { addToPlaylist(track) })
        if (track.source == Track.Source.JAMENDO) {
            if (track.downloadUrl != null) actions.add("Descargar (Jamendo autoriza esta pista)" to { downloadTrack(track) })
            else actions.add("Descarga no autorizada para esta pista" to { showStatus("Jamendo no autoriza descargar esta pista.") })
            track.licenseUrl?.let { license -> actions.add("Ver licencia de la pista" to {
                try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(license))) }
                catch (_: Exception) { showStatus("No se pudo abrir la licencia.") }
            }) }
        }
        AlertDialog.Builder(this).setTitle(track.title).setItems(actions.map { it.first }.toTypedArray()) { _, which -> actions.getOrNull(which)?.second?.invoke() }.show()
    }

    private fun downloadTrack(track: Track) {
        val url = track.downloadUrl ?: return
        try {
            val safeName = "${track.artist} - ${track.title}".replace(Regex("[^A-Za-z0-9 _.-]"), "_").take(100) + ".mp3"
            val destination = File(File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC), "AO-MUSIC-ORK404"), safeName)
            val request = DownloadManager.Request(Uri.parse(url))
                .setTitle(track.title).setDescription("Descarga autorizada por Jamendo")
                .setMimeType("audio/mpeg").setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_MUSIC, "AO-MUSIC-ORK404/$safeName")
            val manager = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            val downloadId = manager.enqueue(request)
            saveDownload(Track("download:${track.id}", track.title, track.artist, track.album, Uri.fromFile(destination).toString(), track.artwork, track.durationMs, Track.Source.DOWNLOAD, licenseUrl = track.licenseUrl), downloadId)
            showStatus("Descarga iniciada: ${destination.name}. Revisa la notificación del sistema.")
        } catch (_: Exception) { showStatus("No se pudo iniciar la descarga. Verifica conexión y espacio disponible.") }
    }

    private fun saveDownload(track: Track, managerId: Long) {
        val records = org.json.JSONArray(prefs.getString("downloads", "[]"))
        val updated = org.json.JSONArray()
        for (i in 0 until records.length()) {
            val old = records.optJSONObject(i) ?: continue
            if (old.optString("id") != track.id) updated.put(old)
        }
        val saved = track.copy(downloadManagerId = managerId)
        updated.put(org.json.JSONObject().put("id", saved.id).put("title", saved.title).put("artist", saved.artist)
            .put("album", saved.album).put("uri", saved.uri).put("artwork", saved.artwork ?: "")
            .put("duration", saved.durationMs).put("license", saved.licenseUrl ?: "").put("managerId", managerId))
        prefs.edit().putString("downloads", updated.toString()).apply()
    }

    private fun downloadedTracks(): List<Track> {
        val arr = try { org.json.JSONArray(prefs.getString("downloads", "[]")) } catch (_: Exception) { org.json.JSONArray() }
        return (0 until arr.length()).mapNotNull { i ->
            val x = arr.optJSONObject(i) ?: return@mapNotNull null
            val fileUri = x.optString("uri", "")
            if (fileUri.isBlank()) return@mapNotNull null
            Track(x.optString("id"), x.optString("title", "Sin título"), x.optString("artist", "Artista"),
                x.optString("album", ""), fileUri, x.optString("artwork", "").takeIf { it.isNotBlank() },
                x.optLong("duration"), Track.Source.DOWNLOAD, licenseUrl = x.optString("license", "").takeIf { it.isNotBlank() },
                downloadManagerId = x.optLong("managerId").takeIf { it > 0 })
        }
    }

    private fun downloadExists(track: Track): Boolean {
        val managerId = track.downloadManagerId
        if (managerId != null) {
            val manager = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            manager.query(DownloadManager.Query().setFilterById(managerId)).use { cursor ->
                return cursor.moveToFirst() && cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)) == DownloadManager.STATUS_SUCCESSFUL
            }
        }
        return Uri.parse(track.uri).path?.let { File(it).exists() } == true
    }

    private fun playlistTracks(): List<Track> {
        val stored = prefs.getString("playlists", "")?.split("\n")?.filter { it.isNotBlank() } ?: emptyList()
        val ids = stored.flatMap { it.substringAfter("|", "").split(",") }.toSet()
        return (allTracks + remoteTracks).distinctBy { it.id }.filter { it.id in ids }
    }

    private fun createPlaylist() {
        val input = EditText(this).apply { hint = "Nombre de playlist" }
        AlertDialog.Builder(this).setTitle("Nueva playlist").setView(input).setNegativeButton("Cancelar", null).setPositiveButton("Crear") { _, _ ->
            val name = input.text.toString().trim()
            if (name.isNotEmpty()) {
                val p = prefs.getString("playlists", "").orEmpty().lines().filter { it.isNotBlank() }.toMutableList()
                if (p.none { it.substringBefore("|").equals(name, true) }) p.add("$name|")
                prefs.edit().putString("playlists", p.joinToString("\n")).apply(); page = "Playlists"; renderTracks(); showStatus("Playlist «$name» creada. Añade canciones desde ⋮.")
            }
        }.show()
    }

    private fun addToPlaylist(track: Track) {
        val playlists = prefs.getString("playlists", "").orEmpty().lines().filter { it.isNotBlank() }
        if (playlists.isEmpty()) { createPlaylist(); showStatus("Primero crea una playlist."); return }
        AlertDialog.Builder(this).setTitle("Añadir a playlist").setItems(playlists.map { it.substringBefore("|") }.toTypedArray()) { _, index ->
            val updated = playlists.toMutableList(); val parts = updated[index].split("|", limit = 2)
            val ids = parts.getOrElse(1) { "" }.split(",").filter { it.isNotBlank() }.toMutableSet(); ids.add(track.id)
            updated[index] = "${parts[0]}|${ids.joinToString(",")}"; prefs.edit().putString("playlists", updated.joinToString("\n")).apply(); showStatus("Canción añadida a ${parts[0]}.")
        }.show()
    }

    private fun openSettings() {
        val input = EditText(this).apply { setText(prefs.getString("jamendo_client_id", "")); hint = "Client ID de Jamendo"; singleLine = true }
        val toggle = CheckBox(this).apply { text = "Tema claro"; isChecked = prefs.getBoolean("light", false) }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(8), dp(22), 0); addView(TextView(this@MainActivity).apply { text = "Jamendo API client_id (opcional). Créalo en developer.jamendo.com. No se envía a AO: solo se usa para sus consultas."; textSize = 13f }); addView(input); addView(toggle) }
        AlertDialog.Builder(this).setTitle("Ajustes · AO MUSIC").setView(box).setNegativeButton("Cancelar", null).setPositiveButton("Guardar") { _, _ ->
            prefs.edit().putString("jamendo_client_id", input.text.toString().trim()).putBoolean("light", toggle.isChecked).apply(); buildUi(); renderTracks()
        }.show()
    }

    private fun showFullPlayer() {
        val track = controller?.currentMediaItem ?: return
        val metadata = track.mediaMetadata
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(24), dp(18), dp(24), dp(10)) }
        val cover = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; background = rounded(0xFF302747.toInt(), 24) }
        metadata.artworkUri?.let { Glide.with(this).load(it).centerCrop().into(cover) } ?: cover.setImageResource(android.R.drawable.ic_media_play)
        box.addView(cover, LinearLayout.LayoutParams(dp(250), dp(250)))
        box.addView(label(metadata.title?.toString() ?: "AO MUSIC", 21f, 0xFFF5F3FF.toInt()).apply { gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD; setPadding(0, dp(18), 0, dp(3)) })
        box.addView(label(metadata.artist?.toString() ?: "Artista", 14f, 0xFFA4A2B5.toInt()).apply { gravity = Gravity.CENTER })
        val controls = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(0, dp(18), 0, dp(8)) }
        controls.addView(control("⏮", 0xFFF5F3FF.toInt()) { controller?.seekToPreviousMediaItem() })
        controls.addView(control("▶ / ⏸", 0xFFC4B5FD.toInt()) { togglePlay() })
        controls.addView(control("⏭", 0xFFF5F3FF.toInt()) { controller?.seekToNextMediaItem() })
        controls.addView(control("🔀", 0xFFF5F3FF.toInt()) { controller?.shuffleModeEnabled = !(controller?.shuffleModeEnabled ?: false) })
        controls.addView(control("🔁", 0xFFF5F3FF.toInt()) { controller?.repeatMode = if (controller?.repeatMode == androidx.media3.common.Player.REPEAT_MODE_ONE) androidx.media3.common.Player.REPEAT_MODE_OFF else androidx.media3.common.Player.REPEAT_MODE_ONE })
        box.addView(controls)
        AlertDialog.Builder(this).setView(box).setPositiveButton("Listo", null).show()
    }

    private fun togglePlay() { controller?.let { if (it.isPlaying) it.pause() else it.play() } ?: showStatus("El reproductor se está iniciando.") }

    private fun updateNowPlaying() {
        val player = controller ?: return
        miniTitle?.text = player.mediaMetadata.title?.toString() ?: "AO MUSIC ORK404"
        miniArtist?.text = player.mediaMetadata.artist?.toString() ?: "Elige una canción"
        playButton?.text = if (player.isPlaying) "⏸" else "▶"
    }

    private val progressUpdater = object : Runnable {
        override fun run() {
            controller?.let { p ->
                val duration = p.duration.takeIf { it > 0 } ?: 0L
                progress?.max = 1000
                if (duration > 0 && progress?.isPressed != true) progress?.progress = (p.currentPosition * 1000 / duration).toInt()
                progressLabel?.text = time(p.currentPosition); val durationView = (progress?.parent as? ViewGroup)?.getChildAt(2) as? TextView; durationView?.text = time(duration)
            }
            handler.postDelayed(this, 600)
        }
    }

    private fun time(ms: Long): String { val seconds = (ms.coerceAtLeast(0) / 1000); return "%d:%02d".format(seconds / 60, seconds % 60) }
    private fun showStatus(text: String) { status?.text = text }
    private fun label(text: String, size: Float, color: Int) = TextView(this).apply { this.text = text; textSize = size; setTextColor(color) }
    private fun control(text: String, color: Int, action: () -> Unit) = TextView(this).apply { this.text = text; textSize = 20f; gravity = Gravity.CENTER; setTextColor(color); setPadding(dp(9), dp(5), dp(9), dp(5)); setOnClickListener { action() } }
    private fun actionButton(text: String, color: String, action: () -> Unit) = TextView(this).apply { this.text = text; textSize = 14f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); background = rounded(Color.parseColor(color), 16); setOnClickListener { action() } }
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    override fun onResume() {
        super.onResume()
        if (page == "Descargas") renderTracks()
    }

    override fun onDestroy() {
        handler.removeCallbacks(progressUpdater)
        controller?.release()
        controller = null
        super.onDestroy()
    }
}
