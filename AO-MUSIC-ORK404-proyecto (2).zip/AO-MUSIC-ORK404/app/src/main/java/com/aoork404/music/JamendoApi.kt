package com.aoork404.music

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

object JamendoApi {
    private val client = OkHttpClient.Builder().callTimeout(25, TimeUnit.SECONDS).build()

    fun search(clientId: String, query: String, done: (List<Track>?, String?) -> Unit) {
        if (clientId.isBlank()) { done(null, "Agrega tu client_id de Jamendo en ⚙ para activar el catálogo."); return }
        val q = URLEncoder.encode(query.trim(), "UTF-8")
        val url = "https://api.jamendo.com/v3.0/tracks/?client_id=${URLEncoder.encode(clientId.trim(), "UTF-8")}&format=json&limit=30&search=$q&audioformat=mp32&imagesize=300&include=musicinfo+licenses"
        val request = Request.Builder().url(url).header("User-Agent", "AOMusicOrk404/1.0 (Android)").build()
        client.newCall(request).enqueue(object : okhttp3.Callback {
            override fun onFailure(call: okhttp3.Call, e: java.io.IOException) { done(null, "No se pudo consultar Jamendo: ${e.message ?: "revisa tu conexión"}") }
            override fun onResponse(call: okhttp3.Call, response: okhttp3.Response) {
                response.use {
                    if (!it.isSuccessful) { done(null, "Jamendo respondió con error HTTP ${it.code}."); return }
                    try {
                        val root = JSONObject(it.body?.string().orEmpty())
                        val results = root.optJSONArray("results") ?: org.json.JSONArray()
                        val tracks = (0 until results.length()).mapNotNull { i ->
                            val x = results.optJSONObject(i) ?: return@mapNotNull null
                            val stream = x.optString("audio", "")
                            if (stream.isBlank() || stream == "null") return@mapNotNull null
                            val canDownload = x.optBoolean("audiodownload_allowed", false)
                            val download = x.optString("audiodownload", "").takeIf { canDownload && it.isNotBlank() && it != "null" }
                            Track(
                                id = "jamendo:${x.optString("id")}",
                                title = x.optString("name", "Sin título"),
                                artist = x.optString("artist_name", "Artista desconocido"),
                                album = x.optString("album_name", "Jamendo"),
                                uri = stream,
                                artwork = x.optString("image", "").takeIf { it.startsWith("https://") },
                                durationMs = x.optLong("duration", 0L) * 1000L,
                                source = Track.Source.JAMENDO,
                                downloadUrl = download,
                                licenseUrl = x.optString("license_ccurl", "").takeIf { it.startsWith("https://") }
                            )
                        }
                        done(tracks, null)
                    } catch (e: Exception) { done(null, "No se pudieron leer los resultados de Jamendo.") }
                }
            }
        })
    }
}
