package com.aoork404.music

import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata

/** One item in the device library or an authorized Jamendo stream. */
data class Track(
    val id: String,
    val title: String,
    val artist: String,
    val album: String,
    val uri: String,
    val artwork: String? = null,
    val durationMs: Long = 0L,
    val source: Source = Source.DEVICE,
    val downloadUrl: String? = null,
    val licenseUrl: String? = null,
    val downloadManagerId: Long? = null
) {
    enum class Source { DEVICE, JAMENDO, DOWNLOAD }

    fun toMediaItem(): MediaItem {
        val metadata = MediaMetadata.Builder()
            .setTitle(title)
            .setArtist(artist)
            .setAlbumTitle(album)
            .apply { artwork?.let { setArtworkUri(Uri.parse(it)) } }
            .build()
        return MediaItem.Builder().setMediaId(id).setUri(uri).setMediaMetadata(metadata).build()
    }
}
